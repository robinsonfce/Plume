import React, { useEffect, useRef, useState, useCallback } from "react";
import * as THREE from "three";

// ─── Physics ──────────────────────────────────────────────────────────────────
const PG = {
  A:[0.22,0.0001,0.20,0.0000], B:[0.16,0.0001,0.12,0.0000],
  C:[0.11,0.0001,0.08,0.0002], D:[0.08,0.0001,0.06,0.0015],
  E:[0.06,0.0001,0.03,0.0003], F:[0.04,0.0001,0.016,0.0003],
};
const STAB_NAMES = { A:"Muy Inestable",B:"Inestable",C:"Mod. Inestable",D:"Neutral",E:"Estable",F:"Muy Estable" };

function sy(x,s){ const[ay,by]=PG[s]; return ay*Math.max(x,0.5)/Math.sqrt(1+by*Math.max(x,0.5)); }
function sz(x,s){ const[,,,bz,az]=[ ...PG[s] ]; const az_=PG[s][2],bz_=PG[s][3]; return Math.max(az_*Math.max(x,0.5)/(1+bz_*Math.max(x,0.5)),0.01); }

function gaussConc(x,y,z,Q,H,stab,uRef){
  if(x<=0) return 0;
  const SY=sy(x,stab), SZ=sz(x,stab);
  const uH=uRef*Math.pow(Math.max(H,0.05)/10,0.14);
  const denom=2*Math.PI*uH*SY*SZ;
  if(denom<1e-30) return 0;
  const gy=Math.exp(-0.5*Math.pow(y/SY,2));
  const gz1=Math.exp(-0.5*Math.pow((z-H)/SZ,2));
  const gz2=Math.exp(-0.5*Math.pow((z+H)/SZ,2));
  const C=Q/denom*gy*(gz1+gz2)*1e6;
  return isFinite(C)?Math.max(0,C):0;
}

// Plasma colormap
function plasma(t){
  t=Math.max(0,Math.min(1,t));
  const stops=[[13,8,135],[86,0,163],[163,0,158],[213,53,126],[240,100,96],[253,153,50],[250,201,28],[240,249,33]];
  const n=stops.length-1, idx=t*n, lo=Math.floor(idx), hi=Math.min(lo+1,n), f=idx-lo;
  return stops[lo].map((v,i)=>(v+f*(stops[hi][i]-v))/255);
}

const GASES = {
  CO:  {Q:42.76e-3, label:"CO",  full:"Monóxido de Carbono (CO)",  erpg1:229100, erpg2:401000, erpg3:573000, lel:null,     color:"#FF8C00", cmap:"hot"},
  HF:  {Q:1.018e-3, label:"HF",  full:"Fluoruro de Hidrógeno (HF)", erpg1:410,   erpg2:10300,  erpg3:40900,  lel:null,     color:"#DC143C", cmap:"reds"},
  HCN: {Q:0.138e-3, label:"HCN", full:"Cianuro de Hidrógeno (HCN)",erpg1:553,   erpg2:11100,  erpg3:27700,  lel:null,     color:"#9400D3", cmap:"purp"},
  H2:  {Q:4.10e-3,  label:"H₂",  full:"Hidrógeno (H₂)",            erpg1:null,  erpg2:null,   erpg3:null,   lel:33600000, color:"#FFD700", cmap:"gold"},
  CH4: {Q:16.33e-3, label:"CH₄", full:"Metano (CH₄)",               erpg1:null,  erpg2:null,   erpg3:null,   lel:26530000, color:"#32CD32", cmap:"grn"},
};

// Scene coordinate transform (real m → scene units)
// x=downwind(Z), y=lateral(X), z=height(Y) — Y-up Three.js
const SH = 1/12;  // horizontal scale: 240m → 20 units
const SV = 1/4;   // vertical scale: 20m → 5 units (exaggeration ×3)

function toScene(xr,yr,zr){ return [yr*SH, zr*SV, xr*SH]; }

// ─── Distance finder ──────────────────────────────────────────────────────────
function findDist(Q,H,stab,uRef,threshold,xMax=800){
  if(!threshold) return null;
  for(let x=1;x<=xMax;x+=2){
    const C=gaussConc(x,0,1.5,Q,H,stab,uRef)*0.699;
    if(C<threshold) return x-2;
  }
  return xMax;
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function BessPlume3D(){
  const canvasRef = useRef(null);
  const sceneData = useRef({});
  const mouse     = useRef({down:false,x:0,y:0,button:0});
  const cam       = useRef({theta:2.5, phi:0.38, r:22, tx:0, ty:1.2, tz:9});
  const animRef   = useRef(null);

  const [gas,    setGas]    = useState("CO");
  const [uWind,  setUWind]  = useState(3.5);
  const [stab,   setStab]   = useState("D");
  const [showE2, setShowE2] = useState(true);
  const [showE3, setShowE3] = useState(false);
  const [showLEL,setShowLEL]= useState(true);
  const [autoRot,setAutoRot]= useState(false);
  const [distInfo,setDistInfo]=useState({e2:null,e3:null,lel:null});

  // ── Init Three.js scene ──────────────────────────────────────────────────
  useEffect(()=>{
    const canvas=canvasRef.current;
    if(!canvas) return;

    const renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false});
    renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
    renderer.setClearColor(0x06090f,1);

    const scene=new THREE.Scene();
    scene.fog=new THREE.FogExp2(0x06090f,0.018);

    const camera=new THREE.PerspectiveCamera(50,1,0.01,600);

    // ── Ground grid ─────────────────────────────────────────────────────
    const gridMat=new THREE.LineBasicMaterial({color:0x1a2535,transparent:true,opacity:0.7});
    const gridGeo=new THREE.BufferGeometry();
    const gLines=[];
    for(let i=-8;i<=24;i+=2){ // Z lines (downwind)
      gLines.push(-8,0,i, 8,0,i);
    }
    for(let i=-8;i<=8;i+=2){ // X lines (lateral)
      gLines.push(i,0,-8, i,0,24);
    }
    gridGeo.setAttribute('position',new THREE.Float32BufferAttribute(gLines,3));
    scene.add(new THREE.LineSegments(gridGeo,gridMat));

    // ── Distance tick marks on ground ───────────────────────────────────
    const tickMat=new THREE.LineBasicMaterial({color:0x1e3a5f,transparent:true,opacity:0.8});
    const tickGeo=new THREE.BufferGeometry();
    const ticks=[];
    [50,100,150,200].forEach(d=>{
      const z=d*SH;
      ticks.push(-0.5,0.01,z, 0.5,0.01,z);
    });
    tickGeo.setAttribute('position',new THREE.Float32BufferAttribute(ticks,3));
    scene.add(new THREE.LineSegments(tickGeo,tickMat));

    // ── Source marker ───────────────────────────────────────────────────
    const srcGrp=new THREE.Group();
    const srcGeo=new THREE.SphereGeometry(0.18,20,20);
    const srcMat=new THREE.MeshBasicMaterial({color:0xFF3333});
    srcGrp.add(new THREE.Mesh(srcGeo,srcMat));

    // Glow ring
    const rGeo=new THREE.RingGeometry(0.25,0.45,40);
    const rMat=new THREE.MeshBasicMaterial({color:0xFF4444,side:THREE.DoubleSide,transparent:true,opacity:0.55});
    const ring=new THREE.Mesh(rGeo,rMat);
    ring.rotation.x=-Math.PI/2;
    ring.position.y=0.02;
    srcGrp.add(ring);

    // Vertical line from source
    const vGeo=new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0,0,0),new THREE.Vector3(0,1.588*SV,0)
    ]);
    srcGrp.add(new THREE.Line(vGeo,new THREE.LineBasicMaterial({color:0xFF6666,transparent:true,opacity:0.6})));
    scene.add(srcGrp);

    // ── Wind arrow ──────────────────────────────────────────────────────
    const arrow=new THREE.ArrowHelper(
      new THREE.Vector3(0,0,1).normalize(),
      new THREE.Vector3(-3,0.3,-1), 2.5, 0x00BFFF, 0.5, 0.3
    );
    scene.add(arrow);

    // ── Plume points (main cloud) ────────────────────────────────────────
    const plumeMat=new THREE.PointsMaterial({
      vertexColors:true, size:0.22, transparent:true, opacity:0.82,
      sizeAttenuation:true, blending:THREE.AdditiveBlending, depthWrite:false
    });
    const plumePts=new THREE.Points(new THREE.BufferGeometry(),plumeMat);
    scene.add(plumePts);

    // ── ERPG-2 zone (magenta glow) ───────────────────────────────────────
    const e2Mat=new THREE.PointsMaterial({
      vertexColors:true, size:0.35, transparent:true, opacity:0.95,
      sizeAttenuation:true, blending:THREE.AdditiveBlending, depthWrite:false
    });
    const e2Pts=new THREE.Points(new THREE.BufferGeometry(),e2Mat);
    scene.add(e2Pts);

    // ── ERPG-3 / LEL zone (red glow) ────────────────────────────────────
    const e3Mat=new THREE.PointsMaterial({
      color:0xFF2222, size:0.42, transparent:true, opacity:0.9,
      sizeAttenuation:true, blending:THREE.AdditiveBlending, depthWrite:false
    });
    const e3Pts=new THREE.Points(new THREE.BufferGeometry(),e3Mat);
    scene.add(e3Pts);

    // ── Coordinate axis helper ───────────────────────────────────────────
    const axes=new THREE.AxesHelper(1.2);
    scene.add(axes);

    sceneData.current={renderer,scene,camera,plumePts,e2Pts,e3Pts,srcGrp,arrow};

    // ── Resize handler ───────────────────────────────────────────────────
    const onResize=()=>{
      const w=canvas.clientWidth, h=canvas.clientHeight;
      renderer.setSize(w,h,false);
      camera.aspect=w/h;
      camera.updateProjectionMatrix();
    };
    onResize();
    window.addEventListener('resize',onResize);

    // ── Animation loop ───────────────────────────────────────────────────
    const tick=()=>{
      animRef.current=requestAnimationFrame(tick);
      // auto-rotate
      if(autoRotRef.current){
        cam.current.theta+=0.003;
      }
      // update camera position from spherical coords
      const {theta,phi,r,tx,ty,tz}=cam.current;
      camera.position.set(
        tx+r*Math.sin(phi)*Math.sin(theta),
        ty+r*Math.cos(phi),
        tz+r*Math.sin(phi)*Math.cos(theta)
      );
      camera.lookAt(tx,ty,tz);
      renderer.render(scene,camera);
    };
    animRef.current=requestAnimationFrame(tick);

    return ()=>{
      cancelAnimationFrame(animRef.current);
      window.removeEventListener('resize',onResize);
      renderer.dispose();
    };
  },[]);

  const autoRotRef=useRef(false);
  useEffect(()=>{ autoRotRef.current=autoRot; },[autoRot]);

  // ── Recompute plume cloud ────────────────────────────────────────────────
  useEffect(()=>{
    const {plumePts,e2Pts,e3Pts}=sceneData.current;
    if(!plumePts) return;

    const gp=GASES[gas];
    const Q=gp.Q;
    const H_eff=1.588; // m effective height
    const AVG_CORR=0.699; // τ=1h/τ=10min correction

    // Grid
    const NX=62, NY=38, NZ=22;
    const x0=1, x1=250;
    const y0=-70, y1=70;
    const z0=0.1, z1=20;
    const dx=(x1-x0)/(NX-1), dy=(y1-y0)/(NY-1), dz=(z1-z0)/(NZ-1);

    // First pass: find C_max on centerline
    let C_max=0;
    for(let ix=0;ix<NX;ix++){
      const xr=x0+ix*dx;
      for(let iz=0;iz<NZ;iz++){
        const C=gaussConc(xr,0,z0+iz*dz,Q,H_eff,stab,uWind);
        if(C>C_max) C_max=C;
      }
    }
    const C_min_show=C_max*3e-5;
    if(C_max<1e-20){ return; }

    const logCmax=Math.log10(C_max), logCmin=Math.log10(C_min_show);

    const posArr=[], colArr=[];
    const e2posArr=[], e2colArr=[];
    const e3posArr=[];
    const E2=gp.erpg2||gp.lel, E3=gp.erpg3;

    for(let ix=0;ix<NX;ix++){
      const xr=x0+ix*dx;
      for(let iy=0;iy<NY;iy++){
        const yr=y0+iy*dy;
        for(let iz=0;iz<NZ;iz++){
          const zr=z0+iz*dz;
          let C=gaussConc(xr,yr,zr,Q,H_eff,stab,uWind);

          // HF dry deposition (Horst simplified)
          if(gas==='HF'){
            const uH=uWind*Math.pow(Math.max(H_eff,0.05)/10,0.14);
            const sz0=Math.max(PG[stab][2]*xr/(1+PG[stab][3]*xr),0.01);
            const K=0.01*Math.sqrt(2/Math.PI)/(uH*sz0)*Math.exp(-(H_eff*H_eff)/(2*(sz0*sz0)));
            C*=Math.exp(-K*xr);
          }

          if(C<C_min_show) continue;

          const [sx,sy_s,szs]=toScene(xr,yr,zr);

          // Plasma color log-normalized
          const t=Math.max(0,Math.min(1,(Math.log10(C)-logCmin)/(logCmax-logCmin)));
          const [r,g,b]=plasma(t);
          const brightness=0.15+t*0.85;
          posArr.push(sx,sy_s,szs);
          colArr.push(r*brightness,g*brightness,b*brightness);

          // Threshold zones
          const C_eff=C*AVG_CORR;
          if(E2 && C_eff>=E2){
            e2posArr.push(sx,sy_s,szs);
            e2colArr.push(1.0,0.1,1.0); // magenta
          }
          if(E3 && C_eff>=E3){
            e3posArr.push(sx,sy_s,szs);
          }
        }
      }
    }

    const updatePts=(pts,pos,col)=>{
      const geo=new THREE.BufferGeometry();
      if(pos.length>0){
        geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));
        if(col) geo.setAttribute('color',new THREE.Float32BufferAttribute(col,3));
      }
      pts.geometry.dispose();
      pts.geometry=geo;
    };

    updatePts(plumePts,posArr,colArr);
    updatePts(e2Pts,e2posArr,e2colArr);
    updatePts(e3Pts,e3posArr,null);
    e2Pts.visible=showE2;
    e3Pts.visible=showE3||showLEL;

    // Compute distances
    const d2=findDist(Q,H_eff,stab,uWind,E2);
    const d3=findDist(Q,H_eff,stab,uWind,E3);
    const dlel=gp.lel ? findDist(Q,H_eff,stab,uWind,gp.lel) : null;
    setDistInfo({e2:d2, e3:d3, lel:dlel, cmax:C_max});

  },[gas,uWind,stab]);

  // Toggle visibility without recompute
  useEffect(()=>{
    const {e2Pts,e3Pts}=sceneData.current;
    if(e2Pts) e2Pts.visible=showE2;
    if(e3Pts) e3Pts.visible=showE3||showLEL;
  },[showE2,showE3,showLEL]);

  // ── Mouse / touch controls ──────────────────────────────────────────────
  const onMouseDown=e=>{
    mouse.current={down:true,x:e.clientX,y:e.clientY,button:e.button};
    e.preventDefault();
  };
  const onMouseUp=()=>{ mouse.current.down=false; };
  const onMouseMove=e=>{
    if(!mouse.current.down) return;
    const dx=e.clientX-mouse.current.x, dy=e.clientY-mouse.current.y;
    mouse.current.x=e.clientX; mouse.current.y=e.clientY;
    if(mouse.current.button===0){
      cam.current.theta-=dx*0.008;
      cam.current.phi=Math.max(0.08,Math.min(Math.PI*0.48,cam.current.phi+dy*0.008));
    } else if(mouse.current.button===2){
      // pan
      const s=cam.current.r*0.001;
      cam.current.tx-=dx*s; cam.current.tz+=dy*s;
    }
  };
  const onWheel=e=>{
    cam.current.r=Math.max(4,Math.min(45,cam.current.r+e.deltaY*0.025));
    e.preventDefault();
  };
  const resetCamera=()=>{
    cam.current={theta:2.5,phi:0.38,r:22,tx:0,ty:1.2,tz:9};
  };

  const gp=GASES[gas];
  const fmt=d=>d==null?'—':`${Math.round(d)} m`;

  return (
    <div style={{
      width:'100vw', height:'100vh', background:'#06090f',
      display:'flex', flexDirection:'row', fontFamily:'"JetBrains Mono","Fira Code",monospace',
      overflow:'hidden'
    }}>
      {/* ── 3D Viewport ──────────────────────────────────────────────────── */}
      <div style={{flex:1,position:'relative'}}>
        <canvas
          ref={canvasRef}
          style={{width:'100%',height:'100%',display:'block',cursor:'crosshair'}}
          onMouseDown={onMouseDown} onMouseUp={onMouseUp}
          onMouseMove={onMouseMove} onMouseLeave={onMouseUp}
          onWheel={onWheel} onContextMenu={e=>e.preventDefault()}
        />

        {/* Top-left HUD */}
        <div style={{
          position:'absolute',top:16,left:16,
          background:'rgba(6,9,15,0.85)',border:'1px solid #1e3a5f',
          borderRadius:6,padding:'10px 14px',backdropFilter:'blur(8px)',
        }}>
          <div style={{color:'#58a6ff',fontWeight:'bold',fontSize:13,letterSpacing:2,marginBottom:4}}>
            ⬡ BESS PLUME · 3D
          </div>
          <div style={{color:'#3d6b9e',fontSize:10,letterSpacing:1}}>UL 9540A · THERMAL RUNAWAY · NMC 18650</div>
          <div style={{color:'#4a7aa8',fontSize:10,marginTop:3}}>
            Copiapó · 391 m.s.n.m. · {uWind} m/s SW→NE · P-G {stab}
          </div>
        </div>

        {/* Bottom legend */}
        <div style={{
          position:'absolute',bottom:16,left:16,
          background:'rgba(6,9,15,0.85)',border:'1px solid #1e3a5f',
          borderRadius:6,padding:'8px 12px',fontSize:10,color:'#4a7aa8',
          backdropFilter:'blur(8px)',
        }}>
          <div style={{marginBottom:4,color:'#3d6b9e',letterSpacing:1}}>CONTROLES</div>
          <div>🖱 Arrastrar: orbitar cámara</div>
          <div>🖱 Click derecho: paneo</div>
          <div>⚙ Scroll: zoom</div>
        </div>

        {/* Bottom center: axis labels */}
        <div style={{
          position:'absolute',bottom:16,left:'50%',transform:'translateX(-50%)',
          display:'flex',gap:18,fontSize:10,
          background:'rgba(6,9,15,0.8)',border:'1px solid #1e3a5f',
          borderRadius:6,padding:'6px 14px',backdropFilter:'blur(8px)',
        }}>
          <span style={{color:'#FF4444'}}>▲ Fuente</span>
          <span style={{color:'#00BFFF'}}>→ Viento NE</span>
          <span style={{color:'#f0f921'}}>● Alta [C]</span>
          <span style={{color:'#FF00FF'}}>● ERPG-2</span>
          <span style={{color:'#FF3333'}}>● ERPG-3</span>
        </div>

        {/* Distance marker labels on canvas overlay */}
        {[50,100,150,200].map(d=>(
          <div key={d} style={{
            position:'absolute',
            bottom: '50%',
            left: `calc(${(d*SH)/(20)*100}%)`,   // rough
            color:'#1e3a5f',fontSize:9,
            pointerEvents:'none',
          }}></div>
        ))}

        {/* Color bar */}
        <div style={{
          position:'absolute',top:16,right:230,
          display:'flex',flexDirection:'column',gap:4,
          background:'rgba(6,9,15,0.85)',border:'1px solid #1e3a5f',
          borderRadius:6,padding:'10px 10px',backdropFilter:'blur(8px)',
          fontSize:10,color:'#4a7aa8',
        }}>
          <div style={{letterSpacing:1,marginBottom:4,color:'#3d6b9e'}}>CONCENTRACIÓN</div>
          <div style={{
            width:18,height:100,
            background:'linear-gradient(to top,#0d0887,#6200a8,#b2307a,#f99340,#f0f921)',
            borderRadius:3,border:'1px solid #1e3a5f',margin:'0 auto',
          }}/>
          <div style={{textAlign:'center',marginTop:2,color:'#f0f921'}}>Máx</div>
          <div style={{textAlign:'center',color:'#0d0887'}}>Mín</div>
          <div style={{color:'#2c4a6e',marginTop:2}}>µg/m³</div>
        </div>
      </div>

      {/* ── Control Panel ──────────────────────────────────────────────────── */}
      <div style={{
        width:210,background:'#0a0f1a',
        borderLeft:'1px solid #1e3a5f',
        display:'flex',flexDirection:'column',
        overflowY:'auto',
      }}>
        {/* Header */}
        <div style={{
          padding:'12px 14px',borderBottom:'1px solid #1e3a5f',
          background:'linear-gradient(180deg,#0d1a2e 0%,#0a0f1a 100%)',
        }}>
          <div style={{color:'#58a6ff',fontSize:11,letterSpacing:2,fontWeight:'bold'}}>PARÁMETROS</div>
        </div>

        <div style={{padding:'12px 14px',display:'flex',flexDirection:'column',gap:16}}>

          {/* Gas selector */}
          <div>
            <div style={{color:'#3d6b9e',fontSize:10,letterSpacing:1,marginBottom:7}}>GAS ACTIVO</div>
            <div style={{display:'flex',flexDirection:'column',gap:3}}>
              {Object.entries(GASES).map(([k,g])=>{
                const active=gas===k;
                return (
                  <button key={k} onClick={()=>setGas(k)} style={{
                    display:'flex',justifyContent:'space-between',alignItems:'center',
                    padding:'5px 9px',fontSize:11,cursor:'pointer',borderRadius:4,
                    border:active?`1px solid ${g.color}`:'1px solid #1e3a5f',
                    background:active?`${g.color}18`:'#06090f',
                    color:active?g.color:'#3d6b9e',
                    transition:'all 0.15s',
                  }}>
                    <span style={{fontWeight:active?'bold':'normal'}}>{g.label}</span>
                    {active && <span style={{fontSize:9,color:g.color+'99'}}>◀</span>}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Wind speed */}
          <div>
            <div style={{display:'flex',justifyContent:'space-between',marginBottom:6}}>
              <span style={{color:'#3d6b9e',fontSize:10,letterSpacing:1}}>VIENTO</span>
              <span style={{color:'#58a6ff',fontSize:11,fontWeight:'bold'}}>{uWind} m/s</span>
            </div>
            <input type="range" min="0.5" max="10" step="0.5" value={uWind}
              onChange={e=>setUWind(+e.target.value)}
              style={{width:'100%',accentColor:'#00BFFF',cursor:'pointer'}}/>
            <div style={{display:'flex',justifyContent:'space-between',fontSize:9,color:'#2c4a6e',marginTop:2}}>
              <span>0.5</span><span>Copiapó →</span><span>10</span>
            </div>
          </div>

          {/* Stability */}
          <div>
            <div style={{color:'#3d6b9e',fontSize:10,letterSpacing:1,marginBottom:7}}>ESTABILIDAD P-G</div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:3}}>
              {['A','B','C','D','E','F'].map(s=>(
                <button key={s} onClick={()=>setStab(s)} style={{
                  padding:'4px 0',fontSize:12,cursor:'pointer',borderRadius:4,fontWeight:'bold',
                  border:stab===s?'1px solid #58a6ff':'1px solid #1e3a5f',
                  background:stab===s?'#0d1a2e':'#06090f',
                  color:stab===s?'#58a6ff':'#2c4a6e',
                }}>
                  {s}
                </button>
              ))}
            </div>
            <div style={{fontSize:9,color:'#2c4a6e',marginTop:5,lineHeight:1.4}}>
              {STAB_NAMES[stab]}
            </div>
          </div>

          {/* Threshold toggles */}
          <div>
            <div style={{color:'#3d6b9e',fontSize:10,letterSpacing:1,marginBottom:8}}>UMBRALES VISIBLES</div>
            {[
              [showE2,setShowE2,'#FF00FF','ERPG-2 / LEL'],
              [showE3,setShowE3,'#FF4444','ERPG-3 / IDLH'],
            ].map(([val,setter,color,label])=>(
              <label key={label} style={{
                display:'flex',alignItems:'center',gap:8,marginBottom:8,
                cursor:'pointer',
              }}>
                <div style={{
                  width:14,height:14,borderRadius:2,flexShrink:0,
                  border:`2px solid ${val?color:'#1e3a5f'}`,
                  background:val?color+'33':'transparent',
                  display:'flex',alignItems:'center',justifyContent:'center',
                  transition:'all 0.15s',
                }} onClick={()=>setter(!val)}>
                  {val && <div style={{width:6,height:6,background:color,borderRadius:1}}/>}
                </div>
                <span style={{fontSize:10,color:val?color:'#2c4a6e'}}>{label}</span>
              </label>
            ))}
          </div>

          {/* Distance info */}
          <div style={{
            background:'#06090f',border:'1px solid #1e3a5f',
            borderRadius:5,padding:'10px 12px',
          }}>
            <div style={{color:'#3d6b9e',fontSize:10,letterSpacing:1,marginBottom:8}}>DISTANCIAS EXCLUSIÓN</div>
            <div style={{display:'flex',flexDirection:'column',gap:5}}>
              {gp.erpg2 && (
                <div style={{display:'flex',justifyContent:'space-between',fontSize:10}}>
                  <span style={{color:'#FF00FF'}}>ERPG-2</span>
                  <span style={{color:distInfo.e2>0?'#e6edf3':'#2c4a6e',fontWeight:'bold'}}>
                    {fmt(distInfo.e2)}
                  </span>
                </div>
              )}
              {gp.erpg3 && (
                <div style={{display:'flex',justifyContent:'space-between',fontSize:10}}>
                  <span style={{color:'#FF4444'}}>ERPG-3</span>
                  <span style={{color:distInfo.e3>0?'#e6edf3':'#2c4a6e',fontWeight:'bold'}}>
                    {fmt(distInfo.e3)}
                  </span>
                </div>
              )}
              {gp.lel && (
                <div style={{display:'flex',justifyContent:'space-between',fontSize:10}}>
                  <span style={{color:'#FFD700'}}>LEL</span>
                  <span style={{color:distInfo.lel>0?'#e6edf3':'#2c4a6e',fontWeight:'bold'}}>
                    {fmt(distInfo.lel)}
                  </span>
                </div>
              )}
              {distInfo.cmax && (
                <div style={{borderTop:'1px solid #1e3a5f',paddingTop:5,marginTop:3,
                  display:'flex',justifyContent:'space-between',fontSize:10}}>
                  <span style={{color:'#2c4a6e'}}>C_max</span>
                  <span style={{color:'#4a7aa8'}}>
                    {distInfo.cmax>1e6 ? `${(distInfo.cmax/1e6).toFixed(1)} g/m³`
                      : distInfo.cmax>1e3 ? `${(distInfo.cmax/1e3).toFixed(1)} mg/m³`
                      : `${distInfo.cmax.toFixed(0)} µg/m³`}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Gas info */}
          <div style={{
            background:'#06090f',border:`1px solid ${gp.color}33`,
            borderRadius:5,padding:'10px 12px',
          }}>
            <div style={{color:`${gp.color}99`,fontSize:10,letterSpacing:1,marginBottom:6}}>
              {gp.label} · FUENTE
            </div>
            <div style={{fontSize:10,color:'#2c4a6e',lineHeight:1.7}}>
              <div>Q = {(gp.Q*1000).toFixed(3)} mg/s</div>
              <div>Frac. vol = {
                gas==='CO'?'15.0%':gas==='HF'?'0.50%':
                gas==='HCN'?'0.05%':gas==='H2'?'20.0%':'10.0%'
              }</div>
              <div>H_eff = 1.59 m</div>
              <div style={{marginTop:3,fontSize:9,color:'#1e3a5f'}}>NMC 18650 · 3Ah · 100% SOC</div>
            </div>
          </div>

          {/* Camera controls */}
          <div style={{display:'flex',flexDirection:'column',gap:5}}>
            <button onClick={resetCamera} style={{
              padding:'7px 0',fontSize:10,cursor:'pointer',borderRadius:4,
              border:'1px solid #1e3a5f',background:'#06090f',color:'#3d6b9e',
              letterSpacing:1,transition:'all 0.15s',
            }} onMouseOver={e=>e.target.style.color='#58a6ff'}
               onMouseOut={e=>e.target.style.color='#3d6b9e'}>
              RESET CÁMARA
            </button>
            <button onClick={()=>setAutoRot(v=>!v)} style={{
              padding:'7px 0',fontSize:10,cursor:'pointer',borderRadius:4,
              border:`1px solid ${autoRot?'#58a6ff':'#1e3a5f'}`,
              background:autoRot?'#0d1a2e':'#06090f',
              color:autoRot?'#58a6ff':'#3d6b9e',letterSpacing:1,
            }}>
              {autoRot?'⏹ STOP':'▶ AUTO-ROTAR'}
            </button>
          </div>

          {/* Footer */}
          <div style={{fontSize:9,color:'#1e3a5f',lineHeight:1.6,borderTop:'1px solid #1e3a5f',paddingTop:10}}>
            <div>Modelo: Gaussiano estacionario</div>
            <div>σy,σz: Briggs P-G rural</div>
            <div>Corr. τ: Pasquill (0.699×)</div>
            <div>HF: Depleción seca Horst</div>
            <div style={{marginTop:4,color:'#1a2d47'}}>v2.0 · UL 9540A</div>
          </div>
        </div>
      </div>
    </div>
  );
}
